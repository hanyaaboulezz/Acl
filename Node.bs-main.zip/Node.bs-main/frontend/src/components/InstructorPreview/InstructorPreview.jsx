import React from "react";

const InstructorPreview = (instructor) => {
  return (
   <></>
  );
};

export default InstructorPreview;
